# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).
1. Install NodeJs 16.x and NPM on Ubuntu
2. Update the backend URL in the src/TodoApp.js 
3. Run npm install
4. RUn npm run build
5. Copy the Generated artifacts in nginx server

